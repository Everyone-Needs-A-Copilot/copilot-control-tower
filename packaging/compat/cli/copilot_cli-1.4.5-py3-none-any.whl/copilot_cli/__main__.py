"""Allow running as `python -m copilot_cli`."""

from .main import app

app()
