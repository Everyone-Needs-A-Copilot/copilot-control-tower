"""USPTO API service."""
