"""Infisical secrets management service."""

__version__ = "0.1.0"
