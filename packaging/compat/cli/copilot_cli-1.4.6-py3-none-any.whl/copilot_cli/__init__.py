"""Copilot CLI - Unified CLI for infrastructure, APIs, databases, and monitoring."""

__version__ = "1.4.6"
